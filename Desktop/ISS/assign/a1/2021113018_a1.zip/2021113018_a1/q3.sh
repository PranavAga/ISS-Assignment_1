#!/bin/bash
read file
echo "$(wc --byte<$file)"
echo "$(awk 'END{print NR}' $file)"
echo "$(wc -w<$file)"
awk '{print "Line No:",NR,"- Count of Words:",NF}' $file

# cat $file | tr ' ' '\n'|awk '{freq[$0]++}END{for(k in freq) if(freq[k]>1) print "Word:",k,"- Count of repetition:",freq[k]-1}'

declare -A freq
declare -A uwords
uw=0;
while read -r line
do
    for wr in $line
    do
    if ((freq[$wr]==0))
    then
        uwords[$uw]=$wr
        ((uw+=1))
    fi
    freq[$wr]=$((freq[$wr]+1))
    done
done < $file
len=${#uwords[@]}
for ((i=0;i<len;i++))
do
    if ((freq[${uwords[$i]}]>1))
        then
        echo Word: ${uwords[$i]} - Count of repetition: ${freq[${uwords[$i]}]}
    fi 
done