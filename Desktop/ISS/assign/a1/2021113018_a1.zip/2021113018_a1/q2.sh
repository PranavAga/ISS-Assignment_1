#!/bin/bash
awk 'BEGIN{ FS=". ~" } {print $NF,"once said, \""$1"\"."}' quotes.txt > speech.txt