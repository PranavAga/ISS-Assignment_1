#!/bin/bash

sed '/^\s*$/d' <quotes.txt | awk '!seen[$0]++' quotes.txt 
