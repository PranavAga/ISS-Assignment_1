#!/bin/bash
IFS=',' read -a data

size=${#data[@]}
while [ $size -gt 1 ]
do
    for ((i=0;i<size-1;i++))
    do
    if [[ ${data[$i]} -gt ${data[$i+1]} ]]
        then
        temp=${data[$i]}
        data[$i]=${data[$i+1]}
        data[$i+1]=$temp
    fi
    done
    ((size--))
done

for ((i=0;i<${#data[@]};i++))
    do
    echo "${data[$i]}"
done