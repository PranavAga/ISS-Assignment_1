#!/bin/bash
read string
ogsrting=$string
len=${#string}
# echo "$string" | rev
for ((i=$len-1;i>=0;i--))
    do
    revinc=$revinc${string:$i:1}
    done
echo "$revinc"
echo "$revinc" | tr '[a-z][A-Z][0-9]' '[b-z]a[B-Z]A[1-9]0'
h=$((len/2))
echo $h
echo ${revinc:$h:$h}${string:$h:$h}