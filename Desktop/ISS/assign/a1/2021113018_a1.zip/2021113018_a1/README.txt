Link to GitHub repo: https://github.com/PranavAga/ISS-Assignment_1
q1.sh
    Outputs unique lines in the file quote.txt the terminal, without empty lines
q2.sh
    Outputs quotes in the required format from quotes.txt to speech.txt
q3.sh
    Takes file as input and outputs to terminal in the following sequence:
        <file size in bytes>
        <total number of lines>
        <total number of words>
        <words in line number 1>
        <words in line number 2>
        .
        .
        .
        <word and repetetion count>
        <word and repetetion count>
        .
        .
        .
q4.sh
    Takes csv as input and outputs numbers in each line,
    in sorted order.
q5.sh
    Takes a string as input and outputs to the terminal:
        <string in reverse order>
        <reversed string but with subsequent letters>
        <first half of the string reversed and second half the same>
